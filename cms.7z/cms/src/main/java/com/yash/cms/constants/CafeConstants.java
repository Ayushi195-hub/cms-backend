package com.yash.cms.constants;

public class CafeConstants {
    public static final String SOMETHING_WENT_WRONG="Something went wrong";
    public static final String INVALID_DATA="Invalid Data";
}
